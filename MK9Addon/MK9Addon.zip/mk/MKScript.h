#pragma once

struct LoadCinemaArgs {
    int field0;
    int field4;
    int field8;
    char* postLoad;
    char* postPlay;
    char* ended;
    char* postActivated;
    int   myObj;
    char  pad[32];
    int   field40;       
    const char* cinemaName;
};

class MKScript {
public:

	void Script_StartLoadingCinematic(int a1);
};


