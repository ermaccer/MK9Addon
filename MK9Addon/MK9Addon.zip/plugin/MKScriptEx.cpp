#include "MKScriptEx.h"
#include "..\mk\GameInfo.h"
#include "..\mk\PlayerInfo.h"
#include "..\mk\MKScript.h"
#include <string>
#include <Shlwapi.h>

const char* MKScriptEx::GetCinemaVictimName()
{
    PlayerInfo* attackerInfo = GetGameInfo()->GetAttackerInfo();
    MKCharacter* his_obj = attackerInfo->GetHisObj();

    if (!his_obj)
        return nullptr;

    return (const char*)((int)his_obj + 0x766C);
}


const char* MKScriptEx::GetKratosFatalityPath(const char* cinemaName)
{
    static char kratosFatalityPath[MAX_PATH] = {};

    char cinemaNameLower[128] = {};
    for (int i = 0; i < strlen(cinemaName); i++)
    {
        cinemaNameLower[i] = tolower(cinemaName[i]);
    }

    if (!(strstr(cinemaNameLower, "_fatality")))
        return nullptr;

    const char* victimName = GetCinemaVictimName();

    if (!victimName)
        return nullptr;

    char victimNameLower[128] = {};

    for (int i = 0; i< strlen(victimName); i++)
    {
        victimNameLower[i] = tolower(victimName[i]);
    }

    // NOTE: original scripts check only for CHAR_Kratos or CHAR_Kratos_B, this is more free
    if (!(strstr(victimNameLower, "_kratos")))
        return nullptr;

    std::string newPath = cinemaName;

    size_t pos = newPath.find_first_of("_");

    if (pos == std::string::npos)
        return nullptr;

    newPath.insert(pos, "_Kratos");

    std::string assetPath = "Asset\\" + newPath + ".xxx";

    if (!PathFileExistsA(assetPath.c_str()))
        return nullptr;

    sprintf(kratosFatalityPath, newPath.c_str());
    //printf("%s to %s\n", cinemaName, newPath.c_str());
    return kratosFatalityPath;
}

void MKScriptEx::Script_StartLoadingCinematicHook(int a1)
{
    LoadCinemaArgs* req = (LoadCinemaArgs*)a1;

    if (req && req->cinemaName)
    {
        const char* alt = GetKratosFatalityPath(req->cinemaName);
        if (alt)
            req->cinemaName = (char*)alt;
    }

    Script_StartLoadingCinematic(a1);
}